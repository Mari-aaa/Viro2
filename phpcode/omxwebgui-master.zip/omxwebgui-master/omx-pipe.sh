# pipe commands to fifo file

echo -n "$1" > $2 &